package javaMysqlTest;

import java.sql.SQLException;

public class ProcBoard {
	void run() {
		Disp.showTitle();
		MysqlConnect.dbInit();
		loop: while (true) {
			MysqlConnect.dbPostCount();
			Disp.showMainMenu();
			String cmd = Ci.r("명령입력: ");
			switch (cmd) {
			case "1":
				ProcList.run();
				break;
			case "2":
				String readNo = Ci.r("읽을 글 번호를 입력해주세요:");
				try {
					MysqlConnect.result = MysqlConnect.st.executeQuery("select * from board where b_no ="+readNo);
					MysqlConnect.result.next();
					String title = MysqlConnect.result.getString("b_title");
					String content = MysqlConnect.result.getString("b_text");
					System.out.println("굴제목: "+title);
					System.out.println("글내용: "+content);
				} catch (SQLException e) {
					e.printStackTrace();
				}
				break;
			case "3":
				String title = Ci.rl("제목을 입력해주세요: ");
				String content = Ci.rl("글내용을 입력해주세요: ");
				String id = Ci.rl("작성자id를 입력해주세요: ");
				break;
			case "4":
				String delNo = Ci.r("삭제할 글번호를 입력해주세요:");
				MysqlConnect.dbExecuteUpdate("delete from board where b_no="+delNo);
				break;
			case "5":
				String editNo = Ci.r("수정할 글번호를 입력해주세요:");
				String edTitle = Ci.rl("제목을 입력해주세요:");
				String edId = Ci.rl("작성자id를 입력해주세요:");				
				String edContent = Ci.rl("글내용을 입력해주세요:");
				MysqlConnect.dbExecuteUpdate("update board set b_title='"+edTitle+"',b_id='"+edId+"',b_datetime=now(),b_text='"+edContent+"' where b_no="+editNo);
				break;
			case "0":
				break;
			case "e":
				System.out.println("프로그램 종료");
				break loop;
			}
		}
	}
}
