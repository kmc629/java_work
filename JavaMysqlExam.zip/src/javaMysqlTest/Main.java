package javaMysqlTest;

public class Main {

}
