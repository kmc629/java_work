package com.kmc.board;

import com.kmc.board.Board;

public class Main {
	public static void main(String[] args) {
		Board board = new Board();
		board.run();
	}
}
