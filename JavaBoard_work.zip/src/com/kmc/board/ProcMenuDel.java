package com.kmc.board;

import com.kmc.board.Data;
import com.kmc.board.Post;
import com.kmc.board.Ci;

public class ProcMenuDel {
	static void run() {
		System.out.println("삭제임");
		String cmd = Ci.r("삭제할 글 번호");
		int tempSearchIndex = 0;
		for(int i=0;i<Data.posts.size();i=i+1) {
			if(cmd.equals(Data.posts.get(i).instanceNo+"")) {
				tempSearchIndex = i;
			}
		}
		Data.posts.remove(tempSearchIndex);
		System.out.println("글 수:"+Data.posts.size());
	}
}