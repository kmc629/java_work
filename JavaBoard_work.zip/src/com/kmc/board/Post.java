package com.kmc.board;

import java.time.LocalDate;


public class Post {
	static public int no = 0;
	public int instanceNo = 0;
	public String title;
	public String content;
	public String writer;
	public int hit;
	public String date;
	public Post(String title, String content, String writer, int hit) {
		no = no + 1;		
		instanceNo = no;
		this.title = title;
		this.content = content;
		this.writer = writer;
		this.hit = hit;
		LocalDate now = LocalDate.now();
		date = now.toString();
	}
	public void infoForList() {
		System.out.print("글번호:"+instanceNo);
		System.out.print(" 글제목:"+title);
		System.out.print(" 작성자:"+writer);
		System.out.print(" 조회수:"+hit);
		System.out.println(" 작성일:"+date);
	}
	public void infoForRead() {
		System.out.print("글제목:"+title);
		System.out.print(" 작성자:"+writer);
		System.out.print(" 조회수:"+hit);
		System.out.println(" 작성일:"+date);
		System.out.println("글내용:"+content);
	}
}
