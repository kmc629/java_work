package com.kmc.board;

import com.kmc.board.ProcMenu;
import com.kmc.board.Data;
import com.kmc.board.Disp;

public class Board {
		public static final String VERSION = "v0.0.5";
		public static final String TITLE = "   글쓰기 게시판 (" + VERSION + ")  ";
		public void run() {
			Data.loadData();	
			Disp.title();
			ProcMenu.run();
		}
	}

