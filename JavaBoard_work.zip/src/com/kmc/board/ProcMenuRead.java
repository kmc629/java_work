package com.kmc.board;

import com.kmc.board.Data;
import com.kmc.board.Post;
import com.kmc.board.Disp;
import com.kmc.board.Ci;

public class ProcMenuRead {
	static void run() {
		Cw.wn("읽기임");
		String cmd = Ci.r("읽을 글 번호");
		for(Post p:Data.posts) {
			if(cmd.equals(p.instanceNo+"")) {
				p.infoForRead();
			}
		}		
	}

}
