package com.kmc.board;

import com.kmc.board.Data;
import com.kmc.board.Ci;
import com.kmc.board.Cw;

public class ProcMenuUpdate {
	static void run() {
		System.out.println("업데이트");
		String cmd = Ci.r("수정할 글 번호");
		for(Post p:Data.posts) {
			if(cmd.equals(p.instanceNo+""));
			String content=Ci.rl("수정 할 글내용");
			p.content = content;
			System.out.println("글 수정 됨");
		}
	}
}
