package com.kmc.board;

import com.kmc.board.Data;
import com.kmc.board.Post;

public class ProcMenuList {
	static void run() {
		System.out.println("리스트임");
		for(Post p:Data.posts) {
			p.infoForList();
		}
	}

}
